//
//  CountryCell.swift
//  CursoiOSAdvanced
//
//  Created by Dev2 on 24/10/2019.
//  Copyright © 2019 clasegetafe. All rights reserved.
//

import UIKit

class CountryCell: UITableViewCell {
    static let cellIdentifier = String(describing: CountryCell.self)
    static let cellHeight: CGFloat = 138
    
    @IBOutlet weak var mView: UIView!
    @IBOutlet weak var mLabel1: UILabel!
    @IBOutlet weak var mTextField1: UITextField!
    @IBOutlet weak var mLabel2: UILabel!
    @IBOutlet weak var mTextField2: UITextField!
    @IBOutlet weak var mLabel3: UILabel!
    @IBOutlet weak var mTextField3: UITextField!
    @IBOutlet weak var mLabe4: UILabel!
    @IBOutlet weak var mTextField4: UITextField!
    
    
    
}
