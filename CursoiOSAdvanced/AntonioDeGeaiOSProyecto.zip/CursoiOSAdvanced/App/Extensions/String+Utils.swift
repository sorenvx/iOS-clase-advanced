//
//  String+Utils.swift
//  CursoiOSAdvanced
//
//  Created by Dev2 on 29/10/2019.
//  Copyright © 2019 clasegetafe. All rights reserved.
//

import Foundation
//extension Optional where Wrapped: Collection {
//    var isNilOrEmpty: Bool {
//        
//    }
//}
